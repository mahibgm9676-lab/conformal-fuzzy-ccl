The datasets are public and are not stored here. Run `python 01_prepare_data.py`
to download them (see the main README for the DOIs).
